//滚动条触发置顶块.
$(document).scroll(function() {
  var scroH = $(document).scrollTop();  //滚动高度
  if(scroH >200){  //距离顶部大于2300px时
    $("#a_up")
  .css("left","90%");
  }else{
    $("#a_up")
  .css("left","105%");
  }
});

$(function(){
  $('a').click(function(){
      //根据a标签的href转换为id选择器，获取id元素所处的位置，并高度减50px（这里根据需要自由设置）
      $('html,body').animate({scrollTop: ($($(this).attr('href')).offset().top -50 )},2000);
  });
});
